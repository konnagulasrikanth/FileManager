﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace FileManager
{
    public class DragDropHelper : IDataObject
    {
        private readonly DataObject _dataObject;
        public DragDropHelper(DataObject dataObject)
        {
            _dataObject = dataObject;
        }

        // Implement necessary IDataObject members
        public object GetData(string format) => _dataObject.GetData(format);
        public object GetData(Type format) => _dataObject.GetData(format);
        public object GetData(string format, bool autoConvert) => _dataObject.GetData(format, autoConvert);
        public bool GetDataPresent(string format) => _dataObject.GetDataPresent(format);
        public bool GetDataPresent(Type format) => _dataObject.GetDataPresent(format);
        public bool GetDataPresent(string format, bool autoConvert) => _dataObject.GetDataPresent(format, autoConvert);
        public string[] GetFormats() => _dataObject.GetFormats();
        public string[] GetFormats(bool autoConvert) => _dataObject.GetFormats(autoConvert);
        public void SetData(object data) => _dataObject.SetData(data);
        public void SetData(string format, object data) => _dataObject.SetData(format, data);
        public void SetData(Type format, object data) => _dataObject.SetData(format, data);
         public void SetData(string format, object data, bool autoConvert) => _dataObject.SetData(format, data, autoConvert);
        
       
    }
}

   

